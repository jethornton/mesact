import os, subprocess, sysconfig, distro
from platform import python_version

from PyQt5.QtCore import qVersion, QRegExp, QLocale
from PyQt5.QtGui import QIntValidator, QDoubleValidator, QRegExpValidator

from libmesact import combos
from libmesact import menus

def setup(parent):

	# setup must have variables
	# board names must be set before loading a config at startup
	parent.board_0 = False
	parent.board_1 = False
	parent.board_2 = False

	# spindle limits
	parent.spindle_fwd_min_rpm.setEnabled(False)
	parent.spindle_fwd_max_rpm.setEnabled(False)
	parent.spindle_rev_min_rpm.setEnabled(False)
	parent.spindle_rev_max_rpm.setEnabled(False)

	# spindle feedback
	parent.spindle_feedback_gb.setEnabled(False)
	parent.spindle_feedback_gb.setVisible(False)

	# spindle pid
	parent.spindle_pid_gb.setEnabled(False)
	parent.spindle_pid_gb.setVisible(False)

	# 7i77 spindle setup
	# hide 7i77 spindle checkbox
	parent.c1_spindle_cb.setVisible(False)
	parent.c2_spindle_cb.setVisible(False)

	# hide 7i77 pid default button
	parent.c1_pid_default_5.setVisible(False)
	parent.c2_pid_default_5.setVisible(False)

	parent.platformLB.setText(sysconfig.get_platform())
	parent.pythonLB.setText(python_version())
	parent.pyqt5LB.setText(qVersion())

	flex_version = False
	try: # need to set this before building combos
		flex = subprocess.check_output(['apt-cache', 'policy', 'flexgui'], text=True)
		if len(flex) > 0:
			version = flex.split()[2]
			parent.flex_gui_lb.setText(f'{version}')
			parent.flex_gui = True
			flex_version = True
	except:
		pass

	if not flex_version:
		try:
			if distro.id().lower() == 'fedora':
				res = subprocess.check_output(['rpm', '-q', '--qf', '%{VERSION}', 'flexgui'], text=True, stderr=subprocess.STDOUT).strip()
				if "is not installed" not in res and res:
					parent.flex_gui_lb.setText(f'{res}')
					parent.flex_gui = True
					flex_version = True
		except:
			pass

	if not flex_version:
		parent.flex_gui_lb.setText('Not Installed')
		parent.flex_gui = False

	combos.build(parent)
	# disable some boards until programmed
	#parent.boardCB.model().item(1).setEnabled(False) # 5i24/6i24
	#parent.boardCB.model().item(6).setEnabled(False) # 7i80db16
	#parent.boardCB.model().item(7).setEnabled(False) # 7i80db25
	#parent.boardCB.model().item(8).setEnabled(False) # 7i80hd16
	#parent.boardCB.model().item(9).setEnabled(False) # 7i80hd25
	#parent.boardCB.model().item(10).setEnabled(False) # 7i80hdts

	menus.build(parent)

	# set tab visibility
	parent.mainTW.setTabVisible(3, False)
	parent.mainTW.setTabVisible(4, False)
	parent.mainTW.setTabVisible(5, False)

	parent.hal_tw.setTabVisible(1, False)
	parent.hal_tw.setTabVisible(2, False)
	parent.hal_tw.setTabVisible(3, False)

	libpath = os.path.join(os.path.expanduser('~'), '.local/lib/libmesact/boards')
	if not os.path.exists(libpath):
		os.makedirs(libpath)

	try:
		parent.resize(parent.settings.value('GUI/window_size'))
		parent.move(parent.settings.value('GUI/window_position'))
		parent.no_check_firmware_cb.setChecked(True if parent.settings.value('NAGS/firmware') == "true" else False)
	except:
		pass

	# Firmware tab

	# get emc version if installed
	parent.emcVersionLB.clear()
	parent.emc_version = (0, 0, 0)
	try: # don't crash if your not running debian
		emc = subprocess.check_output(['apt-cache', 'policy', 'linuxcnc-uspace'], text=True)
	except:
		emc = False
		pass

	if emc:
		for line in emc.split('\n'):
			if 'installed' in line.lower():
				version = line.split() # remove leading space
				if len(version) == 2: # split out the version number
					version = version[1]
				if ':' in version: # strip the 1 from version
					version = version.split(':')[1]
					version = '.'.join(version.split('.', 3)[:3])
				if '~' in version:
					version = version.split('~')[0]
				# make damn sure version is valid
				if all(c in "0123456789." for c in version) and version.count('.') > 1:
					parent.emcVersionLB.setText(version)
					parent.emc_version = tuple(int(i) for i in version.split('.'))
				else:
					parent.emcVersionLB.setText('Version Error')
				break

	if parent.emc_version == (0, 0, 0):
		try:
			if distro.id().lower() == 'fedora':
				res = subprocess.check_output(['rpm', '-q', '--qf', '%{VERSION}', 'linuxcnc'], text=True, stderr=subprocess.STDOUT).strip()
				if "is not installed" not in res and res:
					version = res
					if '-' in version:
						version = version.split('-')[0]
					if '~' in version:
						version = version.split('~')[0]
					if all(c in "0123456789." for c in version):
						parent.emcVersionLB.setText(version)
						parts = version.split('.')
						while len(parts) < 3:
							parts.append('0')
						parent.emc_version = tuple(int(i) for i in parts[:3] if i.isdigit())
					else:
						parent.emcVersionLB.setText('Version Error')
		except:
			pass

	if parent.emc_version == (0, 0, 0):
		parent.emcVersionLB.setText('Not Installed')

	# set version specific items
	if parent.emc_version <= (2, 9, 0) and parent.emc_version != (0, 0, 0): # disable spindle_limits_gb
		parent.spindle_limits_gb.setEnabled(False)
		parent.spindle_limits_lb.setText('Spindle Limits require LinuxCNC 2.9.1 or later')

	try:
		mf = subprocess.check_output('mesaflash', encoding='UTF-8')
		if len(mf) > 0:
			version = mf.split()[2]
			parent.mesaflash_version = tuple(int(i) for i in version.replace("-", ".").split(".") if i.isdigit())
			parent.mesaflashVersionLB.setText(version)
			parent.mesaflash = True
			parent.flashed = False
	except FileNotFoundError as error:
		parent.firmwareGB.setEnabled(False)
		parent.verify_board_pb.setEnabled(False)
		parent.mesaflashVersionLB.setText('Not Installed')
		parent.mesaflash = False
		parent.mesaflash_version = ()

	try:
		# Use python 'distro' module for cross-platform OS and Codename support
		dist_name = distro.name(pretty=False).capitalize()
		dist_version = distro.version()
		dist_codename = distro.codename().capitalize()

		parent.os_name_lb.setText(f'{dist_name} {dist_version}')
		parent.os_code_name_lb.setText(f'{dist_codename}' if dist_codename else 'No Codename')
	except Exception:
		parent.os_name_lb.setText('OS Unknown')
		parent.os_code_name_lb.setText('No Codename')

	if parent.settings.contains('STARTUP/config'):
		if parent.settings.value('STARTUP/config', False, type=bool):
			config_file = parent.settings.value('STARTUP/config')
			if os.path.isfile(config_file):
				parent.loadini.load_ini(parent, config_file, 'auto_load')

	parent.configNameLE.setFocus()

	# allow only integers
	only_int = QIntValidator()
	c_locale = QLocale(QLocale.C)
	only_int.setLocale(c_locale)

	only_numbers = QDoubleValidator()
	#only_numbers.setNotation(QDoubleValidator.StandardNotation)
	only_numbers.setLocale(c_locale)
	#validator = QRegExpValidator(QRegExp(r'[0-9].+'))
	#self.lineEdit.setValidator(validator)

	#only_numbers.setNumberOptions(QLocale.RejectGroupSeparator)
	parent.lin_steps_rev_le.setValidator(only_int)
	parent.lin_microsteps_le.setValidator(only_int)
	parent.lin_stepper_teeth_le.setValidator(only_int)
	parent.lin_leadscrew_teeth_le.setValidator(only_int)
	parent.lin_leadscrew_pitch_le.setValidator(only_numbers)
	parent.angular_steps_rev_le.setValidator(only_int)

	# c0_scale_0 c0_min_limit_0 c0_max_limit_0 c0_max_vel_0 c0_max_accel_0
	float_list = ['_scale_', '_min_limit_', '_max_limit_', '_max_vel_',
	'_max_accel_']
	for item in float_list:
		for i in range(3):
			for j in range(6):
				getattr(parent, f'c{i}{item}{j}').setValidator(only_numbers)
